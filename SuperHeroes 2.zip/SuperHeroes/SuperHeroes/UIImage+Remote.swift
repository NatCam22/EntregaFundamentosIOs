//
//  UIImage+Remote.swift
//  SuperHeroes
//
//  Created by Natalia Hernandez on 30/09/23.
//

import UIKit

extension UIImageView{
    func setImage(for url:URL){
        downloadImage(url: url) { [weak self] result in
            //Vemos si en realidad obtuvimos la imagen
            guard case let .success(image) = result else{
                return
            }
            //En caso de que si le asignamos la imagen al UIImageView. De forma asincrona.
            DispatchQueue.main.async {
                self?.image = image
            }
        }
    }
    
    private func downloadImage(
        url:URL,
        completion: @escaping (Result<UIImage, Error>) -> Void
    ){
        let task = URLSession.shared.dataTask(
            with: url) { data, response, _ in
                let result: Result<UIImage, Error>
                
                defer{
                    completion(result)
                }
                
                guard let data, let image = UIImage(data: data) else{
                    result = .failure(NSError(domain: "No image", code: -1))
                    return
                }
                result = .success(image)
            }
        task.resume()
    }
}
