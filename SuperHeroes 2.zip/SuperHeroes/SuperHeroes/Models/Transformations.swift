//
//  Transformations.swift
//  SuperHeroes
//
//  Created by Natalia Hernandez on 28/09/23.
//

import Foundation

struct Transformation: Decodable {
    let photo: URL
    let description, name: String
    let id: String
}
