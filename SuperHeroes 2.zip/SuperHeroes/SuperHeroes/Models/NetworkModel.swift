//
//  NetworkModel.swift
//  SuperHeroes
//
//  Created by Natalia Hernandez on 27/09/23.
//

import Foundation

final class NetworkModel {
    //Creamos un enumerado con los tipos de error que pueda tener el metodo de login
    enum NetworkError: Error{
        case unknown
        case malformedUrl
        case decodingFailed
        case noData
        case statusCode(code: Int?)
        case noToken
    }
    //Creamos un objeto que nos ayuda a crear url de forma mas facil de ver y con menos posibilidad de errores.
    private var baseComponents: URLComponents{
        var components = URLComponents()
        components.scheme = "https"
        components.host = "dragonball.keepcoding.education"
        return components
    }
    
    private var token: String? {
        get{
            if let token = LocalDataModel.getToken(){
                return token
            }
            return nil
        }
        set{
            if let token = newValue{
                LocalDataModel.save(token: token)
            }
        }
    }
    private var session: URLSession
    
    init(session: URLSession = .shared){
        self.session = session
    }
    
    func login(
        user: String,
        password:String,
        //Usamos el Result y por ello ya no requerimos parametros opcionales.
        completion: @escaping (Result<String, NetworkError>) -> Void)
        {
            //Este es el metodo para hacer el login en la API
            
            //Usamos URLSession.
            //Un objeto shared esta siempre en memoria mientras la aplicacion este en memoria.
            //Es una instancia que es llamable y siempre va a ser la misma. Nunca se deinicializa. Estos "Tipo shared" se llaman Singleton
            //Advertencia: usar con cuidado
            var components = baseComponents
            components.path = "/api/auth/login"
            
            guard let url = components.url else {
                completion(.failure(.malformedUrl))
                return
            }
            //Creamos un string formateado. Le pasamos argumentos qwue reemplazan el %@ en el orden en que pasen a la funcion.
            let loginString = String(format: "%@:%@", user, password)
            //Necesitamos hacerle un encode a nuestro loginString
            guard let loginData = loginString.data(using: .utf8) else{
                completion(.failure(.decodingFailed))
                return
            }
            //Lo cambiamos a base 64. Todo este chiste es para codificar el auth de forma segura.
            let base64LoginString = loginData.base64EncodedString()
            //Configuramos el request
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")
            let task = session.dataTask(
                with: request) {[weak self] data, response, error in
                    guard error == nil else{
                        completion(.failure(.unknown))
                        return
                    }
                    guard let data else{
                        completion(.failure(.noData))
                        return
                    }
                    guard (response as? HTTPURLResponse)?.statusCode == 200 else{
                        completion(.failure(.statusCode(code: (response as? HTTPURLResponse)?.statusCode)))
                        return
                    }
                    guard let token = String(data: data, encoding: .utf8) else{
                        completion(.failure(.decodingFailed))
                        return
                    }
                    completion(.success(token))
                    self?.token = token
                }
            //RE importante ese metodo porque si no es como que task nunca se uso,
            //es una variable ahi alegre a la que nadie molesta.
            task.resume()
        }
    
    //Obtenemos la lista de todos los heroes
    func getHeroes(
        completion: @escaping(Result<[Hero], NetworkError>) -> Void)
    {
        var components = baseComponents
        components.path = "/api/heros/all"
        
        guard let url = components.url else {
            completion(.failure(.malformedUrl))
            return
        }
        guard let token else{
            completion(.failure(.noToken))
            return
        }
        //URLComponents haria una composicion de todos los items
        var urlComponents = URLComponents()
        urlComponents.queryItems = [URLQueryItem(name: "name", value: "")]
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = urlComponents.query?.data(using: .utf8)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        let task = session.dataTask(with: request){
            data, response, error in
            guard error == nil else{
                completion(.failure(.unknown))
                return
            }
            guard let data else{
                completion(.failure(.noData))
                return
            }
            guard let heroes = try? JSONDecoder().decode(
                [Hero].self,
                from: data) else{
                completion(.failure(.decodingFailed))
                return
            }
            completion(.success(heroes))
            
        }
        task.resume()
    }
    
    func getTransformations(
        for hero: Hero,
        completion: @escaping (Result<[Transformation], NetworkError>) -> Void){
            //1. Referenciamos la API que ya tenemos definida y seleccionamos el endpoint que vamos a consultar.
            var components = baseComponents
            components.path = "/api/heros/tranformations"
            
            //Definimos la url, de no existir lanzamos error.
            guard let url = components.url else{
                completion(.failure(.malformedUrl))
                return
            }
            guard let token else{
                completion(.failure(.noToken))
                return
            }
            
            //Definimos los componentes a agregar al body (id del heroe correspondiente) y el metodo de la peticion.
            var urlComponents = URLComponents()
            urlComponents.queryItems = [URLQueryItem(name: "id", value: hero.id)]
            
            var request = URLRequest(url: url)
            request.httpMethod =  "POST"
            request.httpBody = urlComponents.query?.data(using: .utf8)
            request.setValue("Bearer  \(token)", forHTTPHeaderField: "Authorization")
            
            //Definimos la sesion
            let task = session.dataTask(with: request){
                data, response, error in
                guard error == nil else{
                    completion(.failure(.unknown))
                    return
                }
                guard let data else{
                    completion(.failure(.noData))
                    return
                }
                guard let transforms = try? JSONDecoder().decode(
                    [Transformation].self,
                    from: data) else{
                    completion(.failure(.decodingFailed))
                    return
                }
                completion(.success(transforms))
                
            }
            //OJO: INICIAR LA SESION
            task.resume()
        }
}
