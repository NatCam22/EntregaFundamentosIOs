//
//  Hero.swift
//  SuperHeroes
//
//  Created by Natalia Hernandez on 27/09/23.
//

import Foundation

// Nos ayudamos de quicktype para definir el modelo de heroe conm las propiedades que viene en el json.
struct Hero: Codable, Equatable{
    let description, name: String
    let photo: URL
    let id: String
    let favorite: Bool
}

//MARK: - Custom Decodable Conformance 
//Hacemos la version manual del asunto.
//extension Hero: Decodable{
//    //El nombre del enumerado es una convencion. CodingKey es una clase de Foundation
//    enum Codingkeys: String, CodingKey {
//        case id
//        case name
//        case photo
//        case description
//        case favorite
//        //Dado el caso de que queremos cambiar un nombre que en el json se escribe distinto
//        // Deberiamos entonces declarar el case como "case favorite = <Nombre del json>"
//    }
//
//    init(from decoder: Decoder) throws {
//        let values = try decoder.container(keyedBy: Codingkeys.self)
//        id = try values.decode(String.self, forKey: .id)
//        name = try values.decode(String.self, forKey: .name)
//        description = try values.decode(String.self, forKey: .description)
//        photo = try values.decode(URL.self, forKey: .photo)
//        favorite = try values.decode(Bool.self, forKey: .favorite)
//    }
//}
