//
//  LocalDataModel.swift
//  SuperHeroes
//
//  Created by Natalia Hernandez on 29/09/23.
//

import Foundation

struct LocalDataModel{
    private static let key =  "SuperHeroesToken"
    //UserDefaults y el .standard son singeltons. AKA tienen el mismo ciclo de vida que la app.
    //UserDefaults guarda los datos en forma de diccionario.
    private static let userDefaults = UserDefaults.standard
    
    static func getToken() -> String? {
        userDefaults.string(forKey: key)
    }
    
    static func save(token:String){
        userDefaults.set(token, forKey: key)
    }
    static func deleteToken(){
        userDefaults.removeObject(forKey: key)
    }
}
