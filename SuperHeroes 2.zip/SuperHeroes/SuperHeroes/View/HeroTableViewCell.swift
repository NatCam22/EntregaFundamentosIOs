//
//  HeroTableViewCell.swift
//  SuperHeroes
//
//  Created by Natalia Hernandez on 30/09/23.
//

import UIKit

class HeroTableViewCell: UITableViewCell {

   
    //MARK: - Identifier
    static let identifier = "HeroTableViewCell"
    
    //MARK: - Outlets
    @IBOutlet weak var heroName: UILabel!
    @IBOutlet weak var heroImage: UIImageView!
    @IBOutlet weak var heroDescription: UILabel!
    
    //MARK: - Configuration
    func configure(with hero: Hero){
        heroImage.setImage(for: hero.photo)
        heroName.text = hero.name
        heroDescription.text = hero.description
    }
    
}
