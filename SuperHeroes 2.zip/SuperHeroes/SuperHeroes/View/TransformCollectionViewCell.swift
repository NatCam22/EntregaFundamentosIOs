//
//  TransformCollectionViewCell.swift
//  SuperHeroes
//
//  Created by Natalia Hernandez on 1/10/23.
//

import UIKit

class TransformCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var nameTrans: UILabel!
    @IBOutlet weak var imageTrans: UIImageView!
    
    static let identifier = "TransformCollectionViewCell"
    
    //MARK: - Configuration
    
    func configure(with transformation: Transformation){
        nameTrans.text = transformation.name
        imageTrans.setImage(for: transformation.photo)
    }

}
