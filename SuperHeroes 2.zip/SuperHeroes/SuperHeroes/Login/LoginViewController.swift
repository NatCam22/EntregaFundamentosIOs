//
//  LoginViewController.swift
//  SuperHeroes
//
//  Created by Adrián Silva on 28/8/23.
//

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var usernameTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    let model = NetworkModel()
    
    @IBAction func continueTapped(_ sender: Any) {
        
        model.login(
            user: usernameTextField.text ?? "",
            password: passwordTextField.text ?? "")
        {    result in
            switch result{
            case let .success(token):
                print("token: \(token)")
                LocalDataModel.save(token: token)
                
            case let .failure(error):
                LocalDataModel.deleteToken()
                print("Error \(error)")
                return
            }
            //Insertar aqui el codigo necesario para que funcione el login.
            //En este caso es lo que se deberia ejecutar cuando se espicha el boton de continuar.
            
        }
        if  LocalDataModel.getToken() != nil{
            var temp: [Hero] = []
            model.getHeroes
            {[weak self] result in
                print(LocalDataModel.getToken() ?? "no hay token")
                switch result{
                case let .success(heros):
                    temp = heros
                    print("temp tiene : heroes\(temp.count)")
                    
                case let .failure(error):
                    print("Error \(error)")
                }
                DispatchQueue.main.async {
                    //Profe lo siento por el doble check pero no entendí bien por qué no estaba sirviendo solo con la verificación de arriba.
                    //Iba a la siguiente página aún sin token. Un misterio que descubriré luego :)
                    if LocalDataModel.getToken() != nil{
                        let heroVC = HeroTableViewController(heros: temp)
                        self?.navigationController?.setViewControllers([heroVC], animated: true)
                    }
                }
            }
            
            
        }
        
    }
}
