//
//  Detail2ViewController.swift
//  SuperHeroes
//
//  Created by Natalia Hernandez on 1/10/23.
//

import UIKit

class Detail2ViewController: UIViewController {

    @IBOutlet weak var transformationName: UILabel!
    @IBOutlet weak var transformationImage: UIImageView!
    @IBOutlet weak var transformationDescription: UILabel!
    
    private let transformation: Transformation
    
    init(transformation: Transformation){
        self.transformation = transformation
        super.init(nibName: nil, bundle: nil)
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = transformation.name
        transformationName.text = transformation.name
        transformationImage.setImage(for: transformation.photo)
        transformationDescription.text = transformation.description

        // Do any additional setup after loading the view.
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
