//
//  TransformationsCollectionViewController.swift
//  SuperHeroes
//
//  Created by Natalia Hernandez on 1/10/23.
//

import UIKit

class TransformationsCollectionViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    
    private var transformations: [Transformation]
    
    init(transformations: [Transformation]){
            self.transformations = transformations
            super.init(nibName: nil, bundle: nil)
        }
        
    @available(*, unavailable)
    required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Transformaciones"
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(
        UINib(nibName: "TransformCollectionViewCell", bundle: nil),
        forCellWithReuseIdentifier: TransformCollectionViewCell.identifier)
    }

}

//MARK: - Datasource
extension TransformationsCollectionViewController: UICollectionViewDataSource{
    
    func collectionView(
        _ collectionView: UICollectionView,
        numberOfItemsInSection section: Int
    ) -> Int{
        return transformations.count
    }
    
    func collectionView(
        _ collectionView: UICollectionView,
        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
            guard let cell = collectionView.dequeueReusableCell(
                withReuseIdentifier: TransformCollectionViewCell.identifier,
                for: indexPath
            ) as? TransformCollectionViewCell else{
                return UICollectionViewCell()
            }
            cell.configure(with: transformations[indexPath.row])
            return cell
        }
    
}
//MARK: - Delegate

extension TransformationsCollectionViewController: UICollectionViewDelegate{
    func collectionView(
        _ collectionView: UICollectionView,
        didSelectItemAt indexPath: IndexPath){
            let transform = transformations[indexPath.row]
            let detailVC = Detail2ViewController(transformation: transform)
            navigationController?.show(detailVC, sender: nil)
        }
}

