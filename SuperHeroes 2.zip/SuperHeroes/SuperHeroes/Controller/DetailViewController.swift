//
//  DetailViewController.swift
//  SuperHeroes
//
//  Created by Natalia Hernandez on 1/10/23.
//

import UIKit

class DetailViewController: UIViewController {
    //MARK: - Outlets
    @IBOutlet weak var heroName: UILabel!
    @IBOutlet weak var heroDescription: UILabel!
    @IBOutlet weak var heroImage: UIImageView!
    
    let model = NetworkModel()
    private let hero: Hero
    //MARK: - Initializers
    init(hero: Hero){
        self.hero = hero
        super.init(nibName: nil, bundle: nil)
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = hero.name
        heroName.text = hero.name
        heroImage.setImage(for: hero.photo)
        heroDescription.text = hero.description
        
    }

    @IBAction func transformationsButton(_ sender: Any) {
        var transforms:[Transformation] = []
        model.getTransformations(for: hero) { result in
            switch result{
            case let .success(transformations):
                print("La cantidad de transformaciones es: \(transformations.count)")
                transforms = transformations
            case let .failure(error):
                print("Error \(error)")
                return
            }
            DispatchQueue.main.async {
                let transformationsVC = TransformationsCollectionViewController(transformations: transforms)
                self.navigationController?.show(transformationsVC, sender: nil)
            }
        }
    }
    

}
