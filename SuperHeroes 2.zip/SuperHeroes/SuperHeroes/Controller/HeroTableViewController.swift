//
//  HeroTableViewController.swift
//  SuperHeroes
//
//  Created by Natalia Hernandez on 30/09/23.
//

import UIKit

class HeroTableViewController: UIViewController {
    
    @IBOutlet weak var heroTableView: UITableView!
    //MARK: - Model
    private var heroes: [Hero]
    
    //MARK: -initializers
    init(heros: [Hero]){
        self.heroes = heros
        super.init(nibName: nil, bundle: nil)
    }
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Heroes"
        //navigationController?.navigationBar.prefersLargeTitles = true
        heroTableView.dataSource = self
        heroTableView.delegate = self
        heroTableView.register(UINib(nibName: "HeroTableViewCell", bundle: nil), forCellReuseIdentifier: HeroTableViewCell.identifier)
        
    }
    
    
    
        
    }


//MARK: - Datasource
extension HeroTableViewController: UITableViewDataSource {
    func tableView(
        _ tableView: UITableView,
        numberOfRowsInSection section: Int
    ) -> Int {
        print("heroes en tableView \(heroes.count)")
        return heroes.count
    }
    
    func tableView(
        _ tableView: UITableView,
        cellForRowAt indexPath: IndexPath
    ) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(
            withIdentifier: HeroTableViewCell.identifier,
            for: indexPath
        ) as? HeroTableViewCell else{
            return UITableViewCell()
        }
        let hero = heroes[indexPath.row]
        cell.configure(with: hero)
        return cell
                
    }
}

//MARK: - HeroTableViewDelegate

extension HeroTableViewController: UITableViewDelegate{
    func tableView(
        _ tableView: UITableView,
        didSelectRowAt indexPath: IndexPath){
            let hero = heroes[indexPath.row]
            let detailViewController = DetailViewController(hero: hero)
            navigationController?.show(detailViewController, sender: nil)
            tableView.deselectRow(at: indexPath, animated: true)
        }
}
