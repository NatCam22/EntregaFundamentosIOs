//
//  NetworkModelTest.swift
//  SuperHeroesTests
//
//  Created by Natalia Hernandez on 30/09/23.
//

import XCTest
//Testable: Podemos ir a todos accesos internal.
@testable import SuperHeroes

final class NetworkModelTest: XCTestCase {
    //sut=subject under test(?)
    private var sut: NetworkModel!
    
    override func setUp() {
        super.setUp()
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [MockURLProtocol.self]
        let session = URLSession(configuration: configuration)
        sut = NetworkModel(session: session)
    }
    override func tearDown() {
        super.tearDown()
        sut = nil
    }
    
    func testGetHeroes(){
        let expectedHeroes = [Hero(description: "", name: "", photo: URL(string: "https://www.google.com/url?sa=i&url=https%3A%2F%2Fpixabay.com%2Fes%2Fimages%2Fsearch%2Furl%2F&psig=AOvVaw2JvDQtb7hMLibYqOHrc2Fv&ust=1696278139729000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCNiyrtHW1YEDFQAAAAAdAAAAABAE")!, id: "", favorite: true)]
        let token = "Some Token"
        let expectation = expectation(description: "Get Heroes success")
        MockURLProtocol.requestHandler = {
            request in
            XCTAssertEqual(request.httpMethod, "POST")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer \(token)")
            let data = try JSONEncoder().encode(expectedHeroes)
            
            let response = try XCTUnwrap(
                HTTPURLResponse(
                    url: URL(string: "https//dragonball.keepcoding.education")!,
                    statusCode: 200,
                    httpVersion: nil,
                    headerFields: ["Content-Type" : "application/json"]))
                return (response, data)
        }
        sut.getHeroes {
            result in
            guard case let .success(heros) = result else{
                XCTFail("Expected success but received \(result)")
                return
            }
            XCTAssertEqual(heros, expectedHeroes)
            expectation.fulfill()
        }
    wait(for: [expectation], timeout: 1)
    }
    
    
    func testLogin(){
        let expectedToken = "Some Token"
        let someUser = "SomeUser"
        let somePassword = "SomePassword"
        let expectation = expectation(description: "Login success")
        MockURLProtocol.requestHandler = {request in
            let loginString = String(format: "%@:%@", someUser, somePassword)
            let loginData = loginString.data(using: .utf8)!
            let base64LoginString = loginData.base64EncodedString()
            
            XCTAssertEqual(request.httpMethod, "POST")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Basic \(base64LoginString)")
            
            let data = try XCTUnwrap(expectedToken.data(using: .utf8))
            let response = try XCTUnwrap(
                HTTPURLResponse(
                    url: URL(string: "https//dragonball.keepcoding.education")!,
                    statusCode: 200,
                    httpVersion: nil,
                    headerFields: ["Content-Type" : "application/json"])
            )
            return(response,data)
        }
        
        sut.login(
            user: someUser,
            password: somePassword) {
                result in
                guard case let .success(token) = result else{
                    XCTFail("Expected success but received \(result)")
                    return
                }
                XCTAssertEqual(token, expectedToken)
                expectation.fulfill()
            }
        wait(for: [expectation], timeout: 1)
    }
}

final class MockURLProtocol: URLProtocol{
    static var error: NetworkModel.NetworkError?
    static var requestHandler: ((URLRequest ) throws -> (HTTPURLResponse, Data))?
    
    override class func canInit(with request: URLRequest) -> Bool {
        return true
    }
    
    override class func canonicalRequest(for request: URLRequest) -> URLRequest {
        return request
    }
    
    override func startLoading() {
        if let error = MockURLProtocol.error{
            client?.urlProtocol(self, didFailWithError: error)
            return
        }
        guard let handler = MockURLProtocol.requestHandler else{
            assertionFailure("Received unexpected request with no handler")
            return
        }
        do{
            let(response, data) = try handler(request)
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: data)
            client?.urlProtocolDidFinishLoading(self)
        }catch {
            client?.urlProtocol(self, didFailWithError: error)
        }
    }
    override func stopLoading() {
        
    }
}
